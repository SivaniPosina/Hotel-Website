import React from 'react';
import './NorIn.css';
import { useState } from 'react';
import { useCart } from '../CartContext';
const cardsData = [
  {
    id: 1,
    image: '1.webp',
    title: 'Mutter Paneer',
    text: 'Delicately flavored paneer  is teamed with peas, in a tangy gravy.',
  },
  {
    id: 2,
    image: '2.jpg',
    title: 'Raima Chawal',
    text: 'Red Kidney Bean curry (rajma dal) with plain boiled rice.',
  },
  {
    id: 3,
    image: '3.webp',
    title: 'Chole Bhature',
    text: 'Mouth-watering meal straight from the Punjabi kitchen.',
  },
  {
    id: 4,
    image: '4.webp',
    title: 'Keer',
    text: 'This creamy rice pudding is delicately flavored with cardamom and is full of nuts.',
  },
  {
    id: 5,
    image: '5.webp',
    title: 'Paneer Butter Masala',
    text: 'This Paneer Butter Masala recipe is a rich and creamy dish of paneer (Indian cottage cheese) .',
  },
  {
    id: 6,
    image: '6.jpg',
    title: 'Gajar Ka Halwa',
    text: 'The popular Indian dessert known as Carrot Halwa (a.k.a. Gajar Ka Halwa in Hindi or Gajrela in Punjabi.',
  },
  {
    id: 7,
    image: '7.jpg',
    title: 'Chana Masala',
    text: 'Chana Masala is a popular Indian dish of white chickpeas in a spicy and tangy gravy.',
  },
  {
    id: 8,
    image: '8.webp',
    title: 'Dal Makhani',
    text: 'The Dal Makhani recipe is a restaurant style version with subtle smoky flavors and creaminess of the lentils.',
  },
  {
    id: 9,
    image: '9.webp',
    title: 'Besan Ladoo',
    text: 'Besan Ladoo is a popular Indian sweet made from gram flour a.k.a besan.',
  },
  {
    id: 10,
    image: '10.jpg',
    title: 'Malai Kofta',
    text: 'Malai’ means cream and ‘Kofta’ are fried balls of various ingredients, popular not only in Indian cuisine, but also in Middle Eastern.',
  },
  {
    id: 11,
    image: '11.webp',
    title: 'Bhindi Masala',
    text: 'If there’s one classic bhindi (okra) dish with North Indian flavors, it is the Bhindi Masala.',
  },
  {
    id: 12,
    image: '12.jpg',
    title: 'Garlic Naan',
    text: 'This Garlic Naan bread is light, soft, fresh, and filled with flavor.',
  },
  // Add more cards as needed
];


function Card(props) {
  const [isAdded, setIsAdded] = useState(false);

  const handleAddToCart = () => {
    setIsAdded(true);
    // You can perform additional actions here, such as sending the data to a cart or performing other logic.
  };

  return (
    <div className="card">
      <img src={props.image} alt={props.title} />
      <div className="card-content">
        <h3>{props.title}</h3>
        <p>{props.text}</p>
        {isAdded ? (
          <button disabled>Added to Cart</button>
        ) : (
          <button onClick={handleAddToCart}>Add to Cart</button>
        )}
      </div>
    </div>
  );
}


function NorIn() {
  const { dispatch } = useCart();

  // const handleAddToCart = (item) => {
  //   dispatch({ type: 'ADD_TO_CART', payload: item });
  // };
  const [addedItemsCount, setAddedItemsCount] = useState(0);

  const handleAddToCart = (item) => {
    dispatch({ type: 'ADD_TO_CART', payload: item });
    // Call the callback function to increment the count
    setAddedItemsCount(addedItemsCount + 1);
  };

  return (
    <div className="App">
        <center>
        <h1>North Indian cuisine</h1>
        <p>"North Indian cuisine is renowned for its rich and diverse flavors, featuring an array of aromatic spices, creamy curries, and delectable tandoori dishes that tantalize the taste buds."</p>
      {cardsData.map((card) => (
        <Card key={card.id} {...card} />
      ))}
      </center>
    </div>
  );
}

export default NorIn;