import React from 'react';
import './SouIn';
import { useState } from 'react';
const cardsData = [
  {
    id: 1,
    image: 's1.jpeg',
    title: 'Dosa',
    text: ' A thin, crispy pancake made from fermented rice and urad dal (black gram).',
  },
  {
    id: 2,
    image: 's2.jpg',
    title: 'Idli',
    text: 'Soft, fluffy steamed rice cakes made from a fermented batter of rice and urad dal.',
  },
  {
    id: 3,
    image: 's3.jpg',
    title: 'Vada',
    text: 'Savory fritters made from urad dal or a mixture of lentils.Often served with sambar or coconut chutney.',
  },
  {
    id: 4,
    image: 's4.jpeg',
    title: 'Hyderabadi Biryani',
    text: 'It is  is a flavorful and aromatic Indian rice dish made with basmati rice, aromatic spices, and chicken.',
  },
  {
    id: 5,
    image: 's5.jpg',
    title: 'Mysore PakMysore',
    text: 'It is known for its melt-in-the-mouth texture and its rich, sweet, and slightly grainy taste..',
  },
  {
    id: 6,
    image: 's6.jpg',
    title: 'Uttapam',
    text: 'Uttapam is popular for its delicious taste, versatility, and cultural significance in South India.',
  },
  {
    id: 7,
    image: 's7.jpg',
    title: 'Pongal',
    text: 'A South Indian rice dish made with rice and split yellow moong dal.It gives wonderful aroma and flavor.',
  },
  {
    id: 8,
    image: 's8.jpg',
    title: 'Payasam',
    text: 'It is a traditional South Indian dessert, is a creamy and sweet dish and enjoyed on special occasions.',
  },
  {
    id: 9,
    image: 's9.jpg',
    title: 'Puttu and Kadala Curry',
    text: 'Puttu and Kadala Curry is a classic South Indian breakfast, featuring steamed rice cakes (Puttu) served with a spiced black chickpea curry.',
  },
  {
    id: 10,
    image: 's10.jpeg',
    title: 'Gutti Vankaya Kura',
    text: 'A spicy Andhra-style eggplant curry, where eggplants are stuffed with a flavorful spice mix. This dish is a favorite in South Indian cuisine.',
  },
  {
    id: 11,
    image: 's11.jpg',
    title: 'Pesarattu',
    text: 'A green gram (moong dal) dosa that is popular in Andhra Pradesh and Telangana, often served with ginger chutney.',
  },
  {
    id: 12,
    image: 's12.jpeg',
    title: 'Jalebi',
    text: 'Jalebi is a sweet treat made from deep-fried wheat flour batter and soaked in sugar syrup.It is a favorite dessert at South Indian festivals.',
  },
  // Add more cards as needed
];


function Card(props) {
  const [isAdded, setIsAdded] = useState(false);

  const handleAddToCart = () => {
    setIsAdded(true);
    // You can perform additional actions here, such as sending the data to a cart or performing other logic.
  };

  return (
    <div className="card">
      <img src={props.image} alt={props.title} />
      <div className="card-content">
        <h3>{props.title}</h3>
        <p>{props.text}</p>
        {isAdded ? (
          <button disabled>Added to Cart</button>
        ) : (
          <button onClick={handleAddToCart}>Add to Cart</button>
        )}
      </div>
    </div>
  );
}

function SouIn() {
  return (
    <div className="App">
        <center>
        <h1>South Indian cuisine</h1>
        <p id="a">"South Indian cuisine is renowned for its diverse and aromatic flavors, characterized by the liberal use of spices, rice offering a wide array of vegetarian and non-vegetarian delights."</p>
      {cardsData.map((card) => (
        <Card key={card.id} {...card} />
      ))}
      </center>
    </div>
  );
}

export default SouIn;