import React from 'react';
import './Mex.css';
import { useState } from 'react';
const cardsData = [
  {
    id: 1,
    image: 'm1.jpeg',
    title: 'Tacos',
    text: 'A taco is a traditional Mexican food consisting of a small hand-sized corn- or wheat-based tortilla topped with a filling.',
  },
  {
    id: 2,
    image: 'm2.jpeg',
    title: 'Enchilada',
    text: 'An enchilada is a Mexican dish consisting of a corn tortilla rolled around a filling and covered with a savory sauce. ',
  },
  {
    id: 3,
    image: 'm3.webp',
    title: 'Burritos',
    text: 'Burritos are a popular Mexican dish consisting of a large flour tortilla filled with various ingredients.',
  },
  {
    id: 4,
    image: 'm4.webp',
    title: 'Quesadilla',
    text: 'A quesadilla is a Mexican dish consisting of a tortilla that is filled primarily with cheese, and sometimes meats, spices, and other fillings.',
  },
  {
    id: 5,
    image: 'm5.jpeg',
    title: 'Chilaquiles',
    text: 'Chilaquiles are a traditional Mexican breakfast dish consisting of corn tortillas cut into quarters and lightly fried.',
  },
  {
    id: 6,
    image: 'm6.jpeg',
    title: 'Barbacoa',
    text: 'Historically, barbacoa references the style of barbecue by the Taino people of the Caribbean.',
  },
  {
    id: 7,
    image: 'm7.webp',
    title: 'Chile relleno',
    text: 'Originating from Puebla, in this dish a green chili pepper is stuffed with diced pork, nuts, and raisins.',
  },
  {
    id: 8,
    image: 'm8.webp',
    title: 'Carnitas',
    text: 'Carnitas are made by braising or simmering pork in oil or preferably lard until tender.',
  },
  {
    id: 9,
    image: 'm9.webp',
    title: 'Churro',
    text: 'A churro is a type of fried dough from Spanish and Portuguese cuisine, made with choux pastry dough piped.',
  },
  {
    id: 10,
    image: 'm10.jpeg',
    title: 'Birria',
    text: 'Birria is a meat stew or soup made from goat, beef, lamb, mutton, or chicken.',
  },
  {
    id: 11,
    image: 'm11.jpg',
    title: 'Concha',
    text: 'Concha, plural conchas, is a traditional Mexican sweet bread roll. Conchas get their name from their round shape.',
  },
  {
    id: 12,
    image: 'm12.jpeg',
    title: 'Aguachile',
    text: 'Aguachile is a Mexican dish made of shrimp, submerged in liquid seasoned with chiltepin peppers, lime juice, salt, slices of cucumber and slices of onion.',
  },
  // Add more cards as needed
];


function Card(props) {
  const [isAdded, setIsAdded] = useState(false);

  const handleAddToCart = () => {
    setIsAdded(true);
    // You can perform additional actions here, such as sending the data to a cart or performing other logic.
  };

  return (
    <div className="card">
      <img src={props.image} alt={props.title} />
      <div className="card-content">
        <h3>{props.title}</h3>
        <p>{props.text}</p>
        {isAdded ? (
          <button disabled>Added to Cart</button>
        ) : (
          <button onClick={handleAddToCart}>Add to Cart</button>
        )}
      </div>
    </div>
  );
}
function Mex() {
  return (
    <div className="App">
        <center>
        <h1>Mexican cuisine</h1>
        <p>"Mexican cuisine is renowned for its bold flavors, vibrant spices, and diverse array of dishes, from sizzling street tacos to rich mole sauces."</p>
      {cardsData.map((card) => (
        <Card key={card.id} {...card} />
      ))}
      </center>
    </div>
  );
}

export default Mex;